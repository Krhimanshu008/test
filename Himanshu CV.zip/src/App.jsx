import { useState } from 'react'
import Taskbar from './components/Taskbar/Taskbar'
import DesktopIcon from './components/Desktop/DesktopIcon'
import WindowContainer from './components/Window/WindowContainer'
import AboutMe from './components/Apps/AboutMe'
import Projects from './components/Apps/Projects'
import PDFViewerApp from './components/Apps/PDFViewerApp'
import ImageViewerApp from './components/Apps/ImageViewerApp'
import MediaPlayerApp from './components/Apps/MediaPlayerApp'
import ChessApp from './components/Apps/ChessApp'
import SudokuApp from './components/Apps/SudokuApp'
import { User, Folder, FileText, Image as ImageIcon, Video, Target, Grid } from 'lucide-react'
import './App.css'

function App() {
  const [openApps, setOpenApps] = useState([])
  const [focusedApp, setFocusedApp] = useState(null)
  
  const apps = [
    { id: 'about', title: 'About Me', icon: <User size={32} color="#0067C0" />, component: <AboutMe /> },
    { id: 'projects', title: 'Projects', icon: <Folder size={32} color="#F8D775" fill="#F8D775" />, component: <Projects /> },
    { id: 'resume', title: 'Resume PDF', icon: <FileText size={32} color="#e81123" />, component: <PDFViewerApp /> },
    { id: 'imageviewer', title: 'Image Viewer', icon: <ImageIcon size={32} color="#00a4ef" />, component: <ImageViewerApp /> },
    { id: 'mediaplayer', title: 'VLC Media Player', icon: <Video size={32} color="#ff8c00" />, component: <MediaPlayerApp /> },
    { id: 'chess', title: 'Chess', icon: <Target size={32} color="#444" />, component: <ChessApp /> },
    { id: 'sudoku', title: 'Sudoku', icon: <Grid size={32} color="#7fba00" />, component: <SudokuApp /> },
  ]

  const openApp = (appId) => {
    let existingApp = openApps.find(a => a.id === appId)
    if (!existingApp) {
      const appToOpen = apps.find(a => a.id === appId)
      setOpenApps([...openApps, { ...appToOpen, minimized: false }])
    } else {
      setOpenApps(openApps.map(a => a.id === appId ? { ...a, minimized: false } : a))
    }
    setFocusedApp(appId)
  }

  const closeApp = (appId) => {
    setOpenApps(openApps.filter(a => a.id !== appId))
    if (focusedApp === appId) setFocusedApp(null)
  }

  const minimizeApp = (appId) => {
    setOpenApps(openApps.map(a => a.id === appId ? { ...a, minimized: true } : a))
    if (focusedApp === appId) setFocusedApp(null)
  }

  const focusApp = (appId) => {
    setOpenApps(openApps.map(a => a.id === appId ? { ...a, minimized: false } : a))
    setFocusedApp(appId)
  }

  return (
    <div className="desktop">
      <div className="desktop-icons">
        {apps.map(app => (
          <DesktopIcon 
            key={app.id} 
            app={app} 
            onDoubleClick={() => openApp(app.id)} 
          />
        ))}
      </div>

      {openApps.map(app => (
        <WindowContainer
          key={app.id}
          app={app}
          isFocused={focusedApp === app.id}
          isMinimized={app.minimized}
          onFocus={() => focusApp(app.id)}
          onClose={() => closeApp(app.id)}
          onMinimize={() => minimizeApp(app.id)}
        >
          {app.component}
        </WindowContainer>
      ))}

      <Taskbar 
        openApps={openApps} 
        focusedApp={focusedApp} 
        onAppClick={focusApp} 
      />
    </div>
  )
}

export default App
