import React, { useState, useRef } from 'react';
import { Rnd } from 'react-rnd';
import { Minus, Square, X, Copy } from 'lucide-react';
import './WindowContainer.css';

const WindowContainer = ({ app, isFocused, isMinimized, onFocus, onClose, onMinimize, children }) => {
  const [isMaximized, setIsMaximized] = useState(false);
  const rndRef = useRef(null);
  
  // Use refs to track position silently without causing React state conflicts
  const currentPosRef = useRef({ x: 100, y: 100, width: 800, height: 600 });
  const prevPosRef = useRef({ x: 100, y: 100, width: 800, height: 600 });

  const toggleMaximize = (e) => {
    if (e) e.stopPropagation();
    if (!rndRef.current) return;

    if (!isMaximized) {
      // Save current position before maximizing
      prevPosRef.current = { ...currentPosRef.current };
      
      // Imperatively maximize
      rndRef.current.updateSize({ width: window.innerWidth, height: window.innerHeight - 48 });
      rndRef.current.updatePosition({ x: 0, y: 0 });
    } else {
      // Imperatively restore
      rndRef.current.updateSize({ width: prevPosRef.current.width, height: prevPosRef.current.height });
      rndRef.current.updatePosition({ x: prevPosRef.current.x, y: prevPosRef.current.y });
    }
    setIsMaximized(!isMaximized);
  };

  return (
    <Rnd
      ref={rndRef}
      default={{
        x: 100,
        y: 100,
        width: 800,
        height: 600
      }}
      onDragStop={(e, d) => {
        currentPosRef.current.x = d.x;
        currentPosRef.current.y = d.y;
      }}
      onResizeStop={(e, direction, ref, delta, position) => {
        currentPosRef.current.width = parseInt(ref.style.width, 10);
        currentPosRef.current.height = parseInt(ref.style.height, 10);
        currentPosRef.current.x = position.x;
        currentPosRef.current.y = position.y;
      }}
      disableDragging={isMaximized}
      enableResizing={isMaximized ? false : undefined}
      minWidth={300}
      minHeight={200}
      dragHandleClassName="window-titlebar"
      className={`window ${isFocused ? 'window-focused' : ''}`}
      style={{ zIndex: isFocused ? 100 : 10, display: isMinimized ? 'none' : 'flex' }}
      onMouseDown={onFocus}
    >
      <div className="window-content glass-panel">
        <div className="window-titlebar" onDoubleClick={toggleMaximize}>
          <div className="titlebar-left">
            <div className="titlebar-icon">{app.icon}</div>
            <span className="titlebar-title">{app.title}</span>
          </div>
          
          <div className="titlebar-controls">
            <button className="control-btn minimize" onClick={(e) => { e.stopPropagation(); onMinimize(); }}>
              <Minus size={16} />
            </button>
            <button className="control-btn maximize" onClick={toggleMaximize}>
              {isMaximized ? <Copy size={14} /> : <Square size={14} />}
            </button>
            <button className="control-btn close" onClick={onClose}>
              <X size={16} />
            </button>
          </div>
        </div>
        
        <div className="window-body">
          {children}
        </div>
      </div>
    </Rnd>
  );
};

export default WindowContainer;
