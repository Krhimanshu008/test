import React from 'react';
import './Apps.css';

const AboutMe = () => {
  return (
    <div className="app-content">
      <div className="about-header">
        <div className="profile-pic">H</div>
        <div className="about-title">
          <h2>Himanshu Kumar</h2>
          <p>Finance Professional & Tech Enthusiast</p>
        </div>
      </div>
      <div className="about-body">
        <h3>About Me</h3>
        <p>
          I'm a finance professional who genuinely enjoys the detail work — whether that's untangling a messy ledger, 
          navigating a statutory audit, or building a cleaner compliance process.
        </p>
        <p>
          With 5+ years across CA firms and industry, I've worked across accounting, auditing, taxation, budgeting, MIS reporting, and cost analysis. 
          I'm currently pursuing CA (Group 1 Cleared) and have a parallel interest in tech — I build tools to automate the repetitive parts of finance work.
        </p>
        
        <div style={{ display: 'flex', gap: '40px', marginTop: '20px' }}>
          <div>
            <h3>Financial Skills</h3>
            <ul className="skills-list">
              <li>Statutory, Tax, and Bank Audits</li>
              <li>GST & Income Tax Compliance</li>
              <li>MIS Reporting & Cost Analysis</li>
              <li>Corporate Laws & MCA Filings</li>
            </ul>
          </div>
          <div>
            <h3>Tech Skills</h3>
            <ul className="skills-list">
              <li>Python & JavaScript</li>
              <li>HTML/CSS</li>
              <li>SQL</li>
              <li>RAG & COMFYUI</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AboutMe;
