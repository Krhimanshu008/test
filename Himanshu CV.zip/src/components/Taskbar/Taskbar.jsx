import React, { useState, useEffect } from 'react';
import { LayoutGrid, Wifi, Volume2, Battery, ChevronUp } from 'lucide-react';
import StartMenu from './StartMenu';
import './Taskbar.css';

const Taskbar = ({ openApps, focusedApp, onAppClick }) => {
  const [time, setTime] = useState(new Date());
  const [showStartMenu, setShowStartMenu] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const toggleStartMenu = () => {
    setShowStartMenu(!showStartMenu);
  };

  return (
    <>
      <div className="taskbar glass-panel">
        <div className="taskbar-left">
          {/* Weather or Widgets could go here */}
        </div>

        <div className="taskbar-center">
          <button className={`taskbar-icon ${showStartMenu ? 'active' : ''}`} onClick={toggleStartMenu}>
            <LayoutGrid color="#0067C0" fill="#0067C0" size={24} />
          </button>
          
          {openApps.map(app => (
            <button 
              key={app.id} 
              className={`taskbar-icon ${focusedApp === app.id ? 'active' : 'open'}`}
              onClick={() => {
                onAppClick(app.id);
                setShowStartMenu(false);
              }}
            >
              <div className="taskbar-icon-img">{app.icon}</div>
              <div className={`indicator ${focusedApp === app.id ? 'indicator-active' : ''}`}></div>
            </button>
          ))}
        </div>

        <div className="taskbar-right">
          <div className="system-tray">
            <ChevronUp size={16} />
            <Wifi size={16} />
            <Volume2 size={16} />
            <Battery size={16} />
          </div>
          <div className="time-date">
            <span>{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            <span>{time.toLocaleDateString()}</span>
          </div>
        </div>
      </div>
      
      {showStartMenu && (
        <StartMenu onClose={() => setShowStartMenu(false)} />
      )}
    </>
  );
};

export default Taskbar;
