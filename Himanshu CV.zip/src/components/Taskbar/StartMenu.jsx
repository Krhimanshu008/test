import React from 'react';
import { motion } from 'framer-motion';
import { Search, User, Settings, Power } from 'lucide-react';
import './StartMenu.css';

const StartMenu = ({ onClose }) => {
  return (
    <motion.div 
      className="start-menu glass-panel"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 50 }}
      transition={{ duration: 0.2 }}
    >
      <div className="search-box">
        <Search size={16} color="#666" />
        <input type="text" placeholder="Type here to search" />
      </div>

      <div className="pinned-apps">
        <h3>Pinned</h3>
        <div className="apps-grid">
          <div className="app-item">
            <User size={32} color="#0067C0" />
            <span>About Me</span>
          </div>
          <div className="app-item">
            <Settings size={32} color="#444" />
            <span>Settings</span>
          </div>
        </div>
      </div>

      <div className="start-footer">
        <div className="user-profile">
          <div className="avatar">H</div>
          <span>Himanshu</span>
        </div>
        <button className="power-btn" onClick={onClose}>
          <Power size={18} />
        </button>
      </div>
    </motion.div>
  );
};

export default StartMenu;
